/*function validate(){
    var name=document.getElementById("name");
    var name=document.getElementById("email");
    var name=document.getElementById("DOB");
    var name=document.getElementById("checkbox1");

    if(name.value==""||email.value=="" ||DOB.value==""){
        alert("Blank values are not allowed");
        return false;
    }
    else{
          
    }
}
function myFunction(){
    var myWindow= window.open("summary.html","params","width=300,height=300");
}*/
function submitForm(){
    var name=document.getElementById("name").value;
    var email=document.getElementById("email").value;
    var dob=document.getElementById("DOB").value;
    console.log(name);
    console.log(email);
    console.log(dob);

   // var name=document.getElementById("checkbox1");

    if(name == ""||email == "" || dob == ""){
        alert("Blank values are not allowed");
    }
    else{
    window= window.open("summary.html?name=" +name+ "email=" +email+ "DOB=" +DOB);
    }
}

